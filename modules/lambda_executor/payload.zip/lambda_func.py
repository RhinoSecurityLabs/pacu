import subprocess
from subprocess import CalledProcessError

def execute(command):
	try:
		return subprocess.check_output(command, stderr=subprocess.STDOUT, shell=True).decode('utf-8')
	except CalledProcessError as error:
		return error.output.decode('utf-8')

def lambda_handler(event, context):
	if 'command' not in event:
		return {
			"statusCode": 400,
			"body": {"Missing Command"}
		}

	output = execute(event['command'])
	return {
		"statusCode":200,
		"body":output.rstrip()
	}